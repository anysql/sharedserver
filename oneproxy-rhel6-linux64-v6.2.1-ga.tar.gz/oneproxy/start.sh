#/bin/bash
#
export ONEPROXY_HOME=`pwd`
ulimit -c unlimited

${ONEPROXY_HOME}/bin/oneproxy --defaults-file=${ONEPROXY_HOME}/conf/proxy.conf
