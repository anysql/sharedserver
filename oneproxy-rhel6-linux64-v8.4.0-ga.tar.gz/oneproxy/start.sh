#/bin/bash
#
WORKDIR=`dirname ${0}`
cd $WORKDIR
export ONEPROXY_HOME=`pwd`
ulimit -c unlimited
${ONEPROXY_HOME}/bin/oneproxy --defaults-file=${ONEPROXY_HOME}/conf/proxy.conf
