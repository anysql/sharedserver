bin/mysql -h 127.0.0.1 -P 4040 -u test -ptest2
bin/mysql -h 127.0.0.1 -P 4041 -u admin -pOneProxy
